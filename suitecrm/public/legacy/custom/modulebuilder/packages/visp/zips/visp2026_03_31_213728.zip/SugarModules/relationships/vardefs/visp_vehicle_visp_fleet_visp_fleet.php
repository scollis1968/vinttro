<?php
// created: 2026-03-31 21:37:28
$dictionary["visp_fleet"]["fields"]["visp_vehicle_visp_fleet"] = array (
  'name' => 'visp_vehicle_visp_fleet',
  'type' => 'link',
  'relationship' => 'visp_vehicle_visp_fleet',
  'source' => 'non-db',
  'module' => 'visp_vehicle',
  'bean_name' => 'visp_vehicle',
  'vname' => 'LBL_VISP_VEHICLE_VISP_FLEET_FROM_VISP_VEHICLE_TITLE',
  'id_name' => 'visp_vehicle_visp_fleetvisp_vehicle_ida',
);
$dictionary["visp_fleet"]["fields"]["visp_vehicle_visp_fleet_name"] = array (
  'name' => 'visp_vehicle_visp_fleet_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_VISP_VEHICLE_VISP_FLEET_FROM_VISP_VEHICLE_TITLE',
  'save' => true,
  'id_name' => 'visp_vehicle_visp_fleetvisp_vehicle_ida',
  'link' => 'visp_vehicle_visp_fleet',
  'table' => 'visp_vehicle',
  'module' => 'visp_vehicle',
  'rname' => 'name',
);
$dictionary["visp_fleet"]["fields"]["visp_vehicle_visp_fleetvisp_vehicle_ida"] = array (
  'name' => 'visp_vehicle_visp_fleetvisp_vehicle_ida',
  'type' => 'link',
  'relationship' => 'visp_vehicle_visp_fleet',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_VISP_VEHICLE_VISP_FLEET_FROM_VISP_VEHICLE_TITLE',
);
