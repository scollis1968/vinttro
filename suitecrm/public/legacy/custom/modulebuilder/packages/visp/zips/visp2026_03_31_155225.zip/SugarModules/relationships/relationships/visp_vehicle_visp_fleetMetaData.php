<?php
// created: 2026-03-31 15:52:24
$dictionary["visp_vehicle_visp_fleet"] = array (
  'true_relationship_type' => 'one-to-one',
  'relationships' => 
  array (
    'visp_vehicle_visp_fleet' => 
    array (
      'lhs_module' => 'visp_vehicle',
      'lhs_table' => 'visp_vehicle',
      'lhs_key' => 'id',
      'rhs_module' => 'visp_fleet',
      'rhs_table' => 'visp_fleet',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'visp_vehicle_visp_fleet_c',
      'join_key_lhs' => 'visp_vehicle_visp_fleetvisp_vehicle_ida',
      'join_key_rhs' => 'visp_vehicle_visp_fleetvisp_fleet_idb',
    ),
  ),
  'table' => 'visp_vehicle_visp_fleet_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'visp_vehicle_visp_fleetvisp_vehicle_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'visp_vehicle_visp_fleetvisp_fleet_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'visp_vehicle_visp_fleetspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'visp_vehicle_visp_fleet_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'visp_vehicle_visp_fleetvisp_vehicle_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'visp_vehicle_visp_fleet_idb2',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'visp_vehicle_visp_fleetvisp_fleet_idb',
      ),
    ),
  ),
);