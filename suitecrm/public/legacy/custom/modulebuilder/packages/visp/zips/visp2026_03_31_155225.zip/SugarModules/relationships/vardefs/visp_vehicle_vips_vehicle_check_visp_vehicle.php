<?php
// created: 2026-03-31 15:52:24
$dictionary["visp_vehicle"]["fields"]["visp_vehicle_vips_vehicle_check"] = array (
  'name' => 'visp_vehicle_vips_vehicle_check',
  'type' => 'link',
  'relationship' => 'visp_vehicle_vips_vehicle_check',
  'source' => 'non-db',
  'module' => 'vips_vehicle_check',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_VISP_VEHICLE_VIPS_VEHICLE_CHECK_FROM_VIPS_VEHICLE_CHECK_TITLE',
);
