<?php
// created: 2026-03-31 15:26:53
$dictionary["visp_vehicle"]["fields"]["visp_vehicle_visp_fleet"] = array (
  'name' => 'visp_vehicle_visp_fleet',
  'type' => 'link',
  'relationship' => 'visp_vehicle_visp_fleet',
  'source' => 'non-db',
  'module' => 'visp_fleet',
  'bean_name' => 'visp_fleet',
  'vname' => 'LBL_VISP_VEHICLE_VISP_FLEET_FROM_VISP_FLEET_TITLE',
  'id_name' => 'visp_vehicle_visp_fleetvisp_fleet_idb',
);
$dictionary["visp_vehicle"]["fields"]["visp_vehicle_visp_fleet_name"] = array (
  'name' => 'visp_vehicle_visp_fleet_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_VISP_VEHICLE_VISP_FLEET_FROM_VISP_FLEET_TITLE',
  'save' => true,
  'id_name' => 'visp_vehicle_visp_fleetvisp_fleet_idb',
  'link' => 'visp_vehicle_visp_fleet',
  'table' => 'visp_fleet',
  'module' => 'visp_fleet',
  'rname' => 'name',
);
$dictionary["visp_vehicle"]["fields"]["visp_vehicle_visp_fleetvisp_fleet_idb"] = array (
  'name' => 'visp_vehicle_visp_fleetvisp_fleet_idb',
  'type' => 'link',
  'relationship' => 'visp_vehicle_visp_fleet',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_VISP_VEHICLE_VISP_FLEET_FROM_VISP_FLEET_TITLE',
);
