<?php
$module_name = 'visp_vehicle';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
    ),
    'advanced_search' => 
    array (
      'main_driver' => 
      array (
        'type' => 'relate',
        'studio' => 'visible',
        'label' => 'LBL_MAIN_DRIVER',
        'id' => 'VIPS_DRIVER_ID_C',
        'link' => true,
        'width' => '10%',
        'default' => true,
        'name' => 'main_driver',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
