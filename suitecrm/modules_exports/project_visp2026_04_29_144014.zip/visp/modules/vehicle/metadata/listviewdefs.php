<?php
$module_name = 'visp_vehicle';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_SERVICE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_SERVICE',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_MOT' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_MOT',
    'width' => '10%',
    'default' => true,
  ),
  'MAIN_DRIVER' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_MAIN_DRIVER',
    'id' => 'VIPS_DRIVER_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'MAKE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MAKE',
    'width' => '10%',
    'default' => true,
  ),
  'MODEL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_MODEL',
    'width' => '10%',
    'default' => true,
  ),
);
