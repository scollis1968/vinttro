<?php
 // created: 2026-03-31 15:52:24
$layout_defs["visp_vehicle"]["subpanel_setup"]['visp_vehicle_vips_vehicle_check'] = array (
  'order' => 100,
  'module' => 'vips_vehicle_check',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_VISP_VEHICLE_VIPS_VEHICLE_CHECK_FROM_VIPS_VEHICLE_CHECK_TITLE',
  'get_subpanel_data' => 'visp_vehicle_vips_vehicle_check',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
